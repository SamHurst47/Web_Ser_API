def test_create_lap_summary(client):
    data = {"year": 2025, "session": "AUS-RACE", "driver": "VER", "lap_number": 1, "gap_ms": 0.5}
    resp = client.post("/lap_summary/", json=data)  # Match router prefix
    assert resp.status_code == 201

def test_list_lap_summaries(client):
    resp = client.get("/lap_summary/")
    assert resp.status_code == 200
    assert isinstance(resp.json(), list)
